﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E05_Carro
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

              //Criar 1 carro
               Carro carro01 = new Carro();    // 1 construtor: carro vazio pa q o utilizador meta os datos q quizer

               carro01.CriarV1();

               carro01.Listar("1");

               Carro carro02 = new Carro("marca1", "modelo1", "cor1", "matricula1", 1, 11);    //2 construtor: carro com valores 

               carro02.Listar("2");
            
               Carro carro03 = new Carro("m1", 1, 2);    // 3 construtor: metade do carro

               carro03.CriarV2();

               carro03.Listar("3");
            }
            catch (Exception ex)    // capturar o error numa variável
            {
                Console.WriteLine("\n\nErro!");
                Console.WriteLine($"Detalhe do erro: ({ex.Message})");

                Console.ReadKey();
            }

            Console.ReadKey();
        }
    }
}
