﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D12_Coleçoes
{
    class Program
    {
        static void Main(string[] args)
        {
            #region ArrayList: inteiros
            //1. Instanciar
            ArrayList listaNumeros = new ArrayList();

            //2. Adicionar Valores com o método Add
            listaNumeros.Add(1);
            listaNumeros.Add(22);
            listaNumeros.Add(-3);
            listaNumeros.Add(4000);

            //3. Adicionar com FOR foi criado para os ARRAYS
            for (int i = 5; i <11; i++)    //FOR TAB TAB y sale parentesis y llaves
            {
                listaNumeros.Add(i);        // sale la lista de numeros automaticamente hasta 11 y ahi cambiar pa tener los q quiera 

            }

            // 500 al 520, incremento de 2 en 2
            for (int i = 500; i < 521; i = i +2)
            {
                listaNumeros.Add(i);
            }

            //4. Listar com FOREACH criado para as coleçoes
            foreach (int item in listaNumeros)
            {
                Console.WriteLine(item);
            }
            #endregion

            Console.ReadKey();
            Console.Clear(); 
            
            #region ArrayList: strings

            //1. Instranciar e adicionar valores
            ArrayList listaStrings = new ArrayList()
            {
                "a",
                "b",
                "c",
                "d"
            };

            //2. Adicionar valores com o método Add
            listaStrings.Add("C#");     // adicionar automaticamente a la lista existente lo que yo quiera nuevo plus
            listaStrings.Add("Microsoft");

            //3. Adicionar valores pela consola
            Console.WriteLine("Nova string; ");
            listaStrings.Add(Console.ReadLine()); 


            //4. Listar
            foreach (string item in listaStrings)
            {
                Console.WriteLine(item);
            }
            #endregion

            Console.ReadKey();
            Console.Clear(); 

            #region ArrayList: pessoas
            ArrayList listaPessoas = new ArrayList();

            Pessoas person01 = new Pessoas();
            Pessoas person02 = new Pessoas();

            person01.Name = "Pessoa 1";
            person01.Location = "Rua 1";

            person02.Name = "Pessoa 2";
            person02.Location = "Rua 2";

            listaPessoas.Add(person01);
            listaPessoas.Add(person02);

            foreach (Pessoas item in listaPessoas)
            {
                Console.WriteLine($"Nome: {item.Name}\t Localidade: {item.Location}");
                Console.WriteLine($"A pessoa {item.Name} mora em {item.Location}");
            }

            #endregion

            Console.ReadKey();
            Console.Clear();

            #region Arraylist: funcionários
            ArrayList listaEmployees = new ArrayList();

            Employee employee01 = new Employee();
            Employee employee02 = new Employee();
            Employee employee03 = new Employee();

            employee01.Name = "aa";
            employee01.Location = "Espinho";
            employee01.Department = "RH";

            employee02.Name = "bb";
            employee02.Location = "Gaia";
            employee02.Department = "Financiero";

            employee03.Name = "cc";
            employee03.Location = "Porto";
            employee03.Department = "Clinico";

            listaEmployees.Add(employee01);
            listaEmployees.Add(employee02);
            listaEmployees.Add(employee03);

            foreach (Employee item in listaEmployees)
            {
                Console.WriteLine($"{item.Name} mora em {item.Location} e trabalha no departamento {item.Department}");
            }
            #endregion

        }
    }
}
