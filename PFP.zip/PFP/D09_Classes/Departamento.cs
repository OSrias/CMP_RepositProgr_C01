﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RH
{

    class Departamento
    {

        #region Properties

        #endregion

        #region Methods

        #endregion

    }

}
